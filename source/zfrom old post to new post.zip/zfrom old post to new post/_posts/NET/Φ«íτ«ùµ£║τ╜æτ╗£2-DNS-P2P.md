---
title: 计算机网络2 -  DNS、P2P
mathjax: true
categories:
  - 计算机网络
tags:
  - 计算机网络
keywords:
  - 计算机网络
abbrlink: 9336ec97
date: 2020-03-18 23:35:20
---

# DNS服务器
&emsp;&emsp; 往往我们访问的网站是www.baidu.com，这个叫名字，他对应的IP为36.152.44.96,这个过程可以使用ping得到，名字到IP是谁为我们在提供服务呢？这时候就出现了DNS服务器，将名字映射为IP，

## 分布式DNS服务器
&emsp;&emsp; 这个必须分布式

## 层次化
&emsp;&emsp; DNS服务器就像一棵决策树一样，每一层都在分类，最顶层是Zone,他知道.com, .edu, .net 等DNS服务器在哪， .edu服务器又知道 .washington.edu ， .cug.edu , .tingshua.edu在哪， 这样一层一层向下

<!---more-->

## 本地DNS服务器
&emsp;&emsp; 就是学校、公司的DNS服务器

## 一个例子
&emsp;&emsp; 比方一个地大的要找gaia.cs.umass.edu, 他就先找地大的DNS服务器dns.cug.edu.cn， 然后找到Zone，然后找到.edu服务器, 然后去找.umass.edu服务器, 然后去找.cs.umass.edu服务器，最后就找到了gaia.cs.umass.edu，然后就找到IP了。

## 递归还是非递归
&emsp;&emsp; 即我问了A，A替我去问B，B回答A，A回答我，这就是递归
&emsp;&emsp; 我问A，A说不知道并让我去问B，我去问B，B回答我，这就是非递归
&emsp;&emsp; 显然本地服务器采取递归，其他服务器采取非递归好。

## DNS缓存
&emsp;&esmp; 缓存两天

## DNS插入新值
&emsp;&emsp; 花钱买域名

## 负载均衡
&emsp;&emsp; 多个IP地址对应一个名字，即服务端有多个IP，他们共用一个名字，这时候DNS服务器收到询问会轮流指向这些IP地址。

# P2P
&emsp;&emsp; 没有服务器，自组织传输，当规模庞大以后会遇到问题

## 发布内容很快
&emsp;&emsp; 当一个文件要发给所有客户端的时候，这个速度是呈现指数增长的。

## 动机
&emsp;&emsp; 上传助人，下载助己。你传给我，我就传给你，这样就能合作

## 分布式哈希表
&emsp;&emsp; 每个节点只储存一部分数据，从而在整个网络上寻址和储存，这样我们就能找到我们要的文件储存在哪。

## BitTorrent协议
&emsp;&emsp; 将文件划分为小块，利用并行机制快速传输数据。
&emsp;&emsp; 首先联系分布式哈希表，把自己加入其中，然后会得到一堆端(peers),与不同的端并行传输数据，优先和快的端传输
&emsp;&emsp; 本身拥有文件但不给别的端传输的端，我们也不给他传文件。
 
