---
title: Boost学习笔记1 - Boost入门
mathjax: true
categories:
  - c++笔记
  - Boost学习笔记
tags:
  - c++笔记
  - Boost学习笔记
keywords:
  - c++笔记
  - Boost学习笔记
abbrlink: 3c251974
date: 2020-03-17 13:34:24
---

# Boost 与c++
&emsp;&emsp; Boost是基于C++标准的现代库，他的源码按照Boost Software License 来发布，允许任何人自由使用、修改和分发。

# Boost有哪些功能？
&emsp;&emsp; Boost强大到拥有超过90个库，但我们暂时只学习其中一部分

<!---more-->

## Any 
&emsp;&emsp; boost::any是一个数据类型，他可以存放任意的类型，例如说一个类型为boost::any的变量可以先存放一个int类型的值，然后替换为一个std::string的类型字符串。

## Array
&emsp;&emsp; 好像是一个数组容器，和std::vector应该差别不大。

## and more ...

# 这个系列的博客来干嘛？
&emsp;&emsp; 这个系列的博客用来介绍Boost提供的接口，不对Boost进行源码分析，关于Boost的源码，预计会在Boost源码分析笔记系列的博客中。
