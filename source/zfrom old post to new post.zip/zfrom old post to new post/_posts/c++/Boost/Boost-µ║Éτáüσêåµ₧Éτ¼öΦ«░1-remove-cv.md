---
title: Boost 源码分析笔记1 - remove_cv
mathjax: true
categories:
  - c++笔记
  - Boost源码分析笔记
tags:
  - c++笔记
  - Boost源码分析笔记
keywords:
  - c++笔记
  - Boost源码分析笔记
abbrlink: 9bf0d2fc
date: 2020-03-17 14:57:43
---


# 先挑一个简单的来分析
&emsp;&emsp; remove_cv 这个模版类能够帮我们去掉类型的const，他的实现很简单，即使用模版元技术：
```cpp
template <class T> struct remove_cv{ typedef T type; };
template <class T> struct remove_cv<T const>{ typedef T type;  };
template <class T> struct remove_cv<T volatile>{ typedef T type; };
template <class T> struct remove_cv<T const volatile>{ typedef T type; };
```
&emsp;&emsp; 这个代码应该非常容易理解，remove_cv的模版是一个T,我们对他做模版偏特化，将const 和volatile分离，然后使用::value就可以得到没有const、volatile的类型了，所以这个类也叫remove_cv。
