---
title: Boost 源码分析笔记4 - is_function
mathjax: true
categories:
  - c++笔记
  - Boost源码分析笔记
tags:
  - c++笔记
  - Boost源码分析笔记
keywords:
  - c++笔记
  - Boost源码分析笔记
abbrlink: b7406417
date: 2020-03-17 16:03:32
---

这个代码就nb了，我还没看懂，先留个坑,我猜了一下，大概是用来判断一个类型是否是函数指针的。
