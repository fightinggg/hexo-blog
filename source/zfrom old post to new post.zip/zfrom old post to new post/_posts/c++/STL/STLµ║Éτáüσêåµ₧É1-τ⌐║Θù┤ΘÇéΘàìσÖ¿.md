---
title: STL源码分析1 - 空间适配器
mathjax: true
categories:
  - c++笔记
  - STL源码分析
tags:
  - c++笔记
  - STL源码分析
keywords:
  - c++笔记
  - STL源码分析
abbrlink: 5b525b39
date: 2020-03-24 19:36:05
---

# 从这开始我们进入《STL源码分析》的学习
&emsp;&emsp; STL分为6大组件: 空间配置器、容器、迭代器、算法、仿函数、配接器

# 空间配置器
&emsp;&emsp; STL的空间适配器事STL的基础，我们不能靠操作系统来为我们管理内存，那样的代价太大了，这不划算，作为一个c/c++开发人员，我们要完全控制我们程序的一切。

# allocator
&emsp;&emsp; 这是他的英文名字，我们的allocator定义了四个操作
- alloc::allocate() 内存配置
- alloc::dellocate() 内存释放
- alloc::construct() 构造对象
- alloc::destroy() 析构对象

<!---more-->

# type_traits<T>
&emsp;&emsp; 一个模版元技术，他是一个类,能够萃取类型的相关信息，模版元详见C++笔记中的Boost源码分析

# destroy
&emsp;&emsp; 对于基本数据类型，我们啥都不用干，对于用户定义的数据类型，我们显示调用析构函数即可，这个使用模版特化即可。

# construct
&emsp;&emsp; 就是new，但是不用申请空间了，因为allocate已经干了

# 一级配置器、二级配置器
&emsp;&emsp; 一级配置大空间(&gt;128bytes)就是malloc和free，二级配置小空间，利用内存池。

## 一级配置器
&emsp;&emsp; 直接new的，new失败以后调用out of memery的处理方式调用处理例程，让其释放内存，不断尝试,释放的时候直接free

## 二级配置器
&emsp;&emsp;维护16个链表，每个链表维护一种类型的内存，分别为8bytes、16bytes、24bytes、一直到128bytes。更加巧妙的地方是将维护的内存和链表的指针使用联合体组装。这就不浪费空间了。当需要配置内存的时候，向8字节对齐，然后再分配，当释放内存的时候，丢到链表里面就行了
&emsp;&emsp; 当链表空了的时候，从内存池中取出20个新的内存块填充链表。
&emsp;&emsp; 内存池是一个大块大内存，当内存池空了以后，申请更多的内存，保证每次都比上一次申请的多就行了，要是让我实现，我才不这样做，我要用计算机网络中的自适应rtt原理来做。


