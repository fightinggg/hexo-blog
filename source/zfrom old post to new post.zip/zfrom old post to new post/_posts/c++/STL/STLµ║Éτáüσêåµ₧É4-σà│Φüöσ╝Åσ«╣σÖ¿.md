---
title: STL源码分析4-关联式容器
mathjax: true
categories:
  - c++笔记
  - STL源码分析
tags:
  - c++笔记
  - STL源码分析
keywords:
  - c++笔记
  - STL源码分析
abbrlink: 49d0094c
date: 2020-03-24 21:30:07
---

# 关联式容器
&emsp;&emsp; 这玩意就是红黑树啦，上一章的序列容器看的我难受死了，希望这个能爽一些

# 红黑树
&emsp;&emsp; 翻了好几页，都是红黑树，并没有让我感到很吃惊的代码

# set和map
&emsp;&emsp; set就是直接红黑树，map就把用pair分别存kv，然后自己定一个仿函数，难怪map找到的都是pair

# multi
&emsp;&emsp; 算了自己写过平衡树的都知道，和非multi没几行代码不一样。

# hashtable
&emsp;&emsp; 下一章下一章。。。
