---
title: STL源码分析8-仿函数
mathjax: true
categories:
  - c++笔记
  - STL源码分析
tags:
  - c++笔记
  - STL源码分析
keywords:
  - c++笔记
  - STL源码分析
abbrlink: 56bc93c8
date: 2020-03-25 22:10:02
---

# 仿函数
&emsp;&emsp; c++的一大特色，通过重载()来实现像函数一样的功能

# 一元仿函数
```cpp
template<class Arg,class Result>
struct unary_function{
  typedef Arg argument_type;
  typedef Result result_type;
};
```
&emsp;&emsp; 看到上面那玩意没，你得继承它。
<!---more-->

- negeta 取反，返回-x
- logical_not  !x
- identity x
- select1st a.first
- select2nd a.second

# 二元仿函数
```cpp
template<class Arg1,class Arg2,class Result>
struct unary_function{
  typedef Arg1 first_argument_type;
  typedef Arg2 second_argument_type;
  typedef Result result_type;
};
```
- plus a+b
- minus a-b
- multiplies a*b
- divides a/b
- modulus a%b
- equal_to a==b
- not_equal_to a!=b
- greater a>b
- greater_equal a>=b
- less a&lt;b
- less_equal a&lt;=b
- logical_and a&&b
- logical_or a||b
- project1st a
- project2nd b

# 仿函数单位元
&emsp;&emsp; 你要为你的仿函数设置一个identity_element单位元，用于快速幂

# 

