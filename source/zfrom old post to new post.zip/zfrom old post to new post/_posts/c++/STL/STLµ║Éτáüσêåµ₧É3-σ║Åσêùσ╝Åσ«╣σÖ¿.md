---
title: STL源码分析3-序列式容器
mathjax: true
categories:
  - c++笔记
  - STL源码分析
tags:
  - c++笔记
  - STL源码分析
keywords:
  - c++笔记
  - STL源码分析
abbrlink: 71655f9
date: 2020-03-24 20:39:33
---

# vector
&emsp;&emsp; 不讲了，太简单了

## vector 的迭代器
&emsp;&emsp; 服了，居然就是指针，我一直以为他封装了一下，这也太懒了。

# list
&emsp;&emsp;算了这都跳过算了，没啥意思，

# deque
&emsp;&emsp; 用分段连续来制造整体连续的假象。
&emsp;&emsp; 两个迭代器维护首尾，一个二维指针维护一个二维数组，感觉很low，每一行被称为一个缓冲区,但是列的话，他前后都预留了一些指针位置。
&emsp;&emsp; 当我们随机访问的时候，就可以根据每一行的长度来选择正确的缓冲区了。
## deque的迭代器
&emsp;&emsp; 这个就厉害一些了，他包含了4个地方，当前指针、当前缓冲区首尾指针，中控器上面当前缓冲区的指针。
## 代码我感觉也一般般，我写也这样

# queue和stack
&emsp;&emsp; 居然是deque实现的，明明有更好的实现方法，再见，看都不想看

# heap
&emsp;&emsp; 算法都是这样写的
## priority heap
&emsp;&emsp; vector实现的，

# slist
我还是不适合这个东西
