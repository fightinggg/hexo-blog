---
title: STL源码分析6-算法2
mathjax: true
categories:
  - c++笔记
  - STL源码分析
tags:
  - c++笔记
  - STL源码分析
keywords:
  - c++笔记
  - STL源码分析
abbrlink: 8445bf94
date: 2020-03-25 19:34:38
---

# partial_sum
&emsp;&emsp; 和前面的差分一样,partial_sum 为前缀和，partial_sum(first,last,result)为前缀和输出到result中
&emsp;&emsp; 当然你也可以定义binary_op操作，加在最后面

# power
&emsp;&emsp; 快速幂算法了解一下，power(x,n)x的n次方，n为整数，要求满足乘法结合律。
&emsp;&emsp; power(x,n,op),这个同理

# itoa
&esmp;&emsp; itoa(first,last,value);
&emsp;&emsp;while(first!=last) *first++=value++;

<!---more-->

# equal
&emsp;&emsp; equal(first1,last1,first2)
&emsp;&emsp; 判断[first1,last1) 和[first2,...)是否相同
&emsp;&emsp; 同样支持二元仿函数。

# fill
&emsp;&emsp; fill(first,last,value)
&emsp;&emsp; 把区间的值设为value

# fill_n
&emsp;&emsp; fill(first,n,value)
&emsp;&emsp; 把first开始的n个元素设为value

# iter_swap
&emsp;&emsp; iter_swap(a,b) 
&emsp;&emsp; 交换迭代器的内容，这里就有意思了，如何获取迭代器内容的类型呢？还记得之前讲迭代器的时候，在迭代器内部定义的value_type吗？对！就是那个。


# lexicographical_compare
&emsp;&emsp; lexicographical_compare(first1,last1,first2,last2)
&emsp;&emsp; 字典序比大小，需要支持小于号

# max min
&emsp;&emsp; 这俩也支持仿函数

# mismatch
&emsp;&emsp; mismatch(first1,last1,first2)
&emsp;&emsp; 用第一个去匹配第二个，你需要保证第二个不必第一个短，返回匹配尾部
&emsp;&emsp; 支持仿函数==

# swap
&emsp;&emsp; 就是很普通的交换，

# copy(first,last,result)
&emsp;&emsp; 特化了char\*和wchar_t\*为memmove，特化了T\*和const T\*，通过萃取，若指向的数据为基本数据类型则调用memmove，否则再分为随机迭代器和非随机迭代器，随机迭代器使用last-first这个值来控制，非随机迭代器用if(last==frist)来控制。

# copy_backward
&emsp;&emsp; 和上面一样，但是为逆序拷贝

# set_union
&emsp;&emsp;set_union(first1,last1,first2,last2,result)
&emsp;&emsp;就是遍历两个有序容器，然后赋值到result中，注意到它在碰到相同元素的时候两个迭代器都自增了，导致若第一个中有3个1，第二个中有5个1，则输出的时候只有5个1

# set_intersection
&emsp;&emsp; 同上
&emsp;&emsp; 交集，得到3个1

# set_difference
&emsp;&esmp; 代码越来越平庸了，这个是S1-S2，出现在S1中不出现在S2中

# set_symmetric_difference
&emsp;&emsp; 对称差，平庸的代码

# adjacent_find(first,last)
&emsp;&emsp; 找到第一个相等的相邻元素，允许自定义仿函数

# count(first,last,value)
&emsp;&emsp; 对value出现对次数计数
&emsp;&emsp; count_if(first,last,op) 对op(*it)为真计数

越看越无聊了

# find(first,last,value)
&emsp;&emsp; 找value出现的位置，这个函数应该挺有用的
&emsp;&emsp; find_if(first,last,op) 同上啦

# find_end 和find_first_of
&emsp;&emsp; 这个函数没用，我为啥不用kmp算法

# for_each(first,last,op)
&emsp;&emsp; op(\*i)

# geterate(first,last,op)
&emsp;&emsp; \*i=op()
&emsp;&emsp; generate_n 同上

# transform(first,last,result,op)
&emsp;&emsp; \*result=op(\*first)

# transform(first1,last1,first2,last2,result,op)
&emsp;&emsp; \*result=op(\*first1,\*first2)

# includes(first1,last1,first2,last2)
&emsp;&emsp; 保证有序，然后判断2是不是1的子序列，显然On

# max_element(first,last) 
&emsp;&emsp; 区间最大值

# min_element(first,last)
&emsp;&emsp; 同上

# merge(first1,last1,first2,last2,result)
&emsp;&emsp; 归并排序的时候应该用得到吧

# partition(first,last,pred)
&emsp;&emsp; pred(*)为真在前，为假在后On

# remove(first,last,value)
&emsp;&emsp; 把value移到尾部
&emsp;&emsp; remove_copu(first,last,result,value),非质变算法

# remove_if remove_copy_if 
同上

# replace(first,last,old_value,new_value)
&emsp;&emsp; 看名字就知道怎么实现的
&emsp;&emsp; replace_copy,replace_if,replace_copy_if

# revese
&emsp;&emsp; 秀得我头皮发麻，这个。。。。。。。
```cpp
while(true)
  if(first==last||first==--last) return;
  else iter_swap(first++,last);
```
&emsp;&emsp;随机迭代器的版本还好
```cpp
while(first<last) iter_swap(first++,--last);
```
&emsp;&emsp; reverse_copy ，常见的代码

#  rotate
&emsp;&emsp; 这个代码有点数学，大概率用不到，一般情况下我们写splay都用3次reverse来实现的，复杂度也不过On,他这个代码就一步到位了，使用了gcd，没啥意思，STL果然效率第一

# search
&emsp;&emsp; 子序列首次出现的位置，

# search_n
&emsp;&emsp; 好偏，算了，没啥用的代码

# swap_ranges(first1,last1,first2)
&emsp;&emsp; 区间交换，swap的增强版

# unique 
&emsp;&emsp; 移除重复元素
&emsp;&emsp; unique_copy






