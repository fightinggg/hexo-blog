---
title: c++基础笔记1 - const与指针
mathjax: true
categories:
  - c++笔记
  - c++基础笔记
tags:
  - c++笔记
  - c++基础笔记
keywords:
  - c++笔记
  - c++基础笔记
abbrlink: 9d4ba271
date: 2020-03-13 15:23:53
---

# 前言
&emsp;&emsp; 从大一上接触c++,到大一下接触ACM,到现在大三下,我自以为对c++有了很深的理解，其实不然，我不清楚的地方还特别多，准备趁此空闲时间重学c++。

# const 与指针
&emsp;&emsp; 这是这篇博文的重点，常常我们会碰到多种声明
```cpp
const char* const a = new char[10];
const char* a = new char[10];
char* const a = new char[10];
char* a = new char[10];
```

&emsp;&emsp; 他们有什么共性与不同呢?下面的程序演示了区别，注释的地方是非法操作会报错。
```cpp
#include <iostream>
using namespace std;
int main() {
  const char* const a = new char[10];
  const char* b = new char[10];
  char* const c = new char[10];
  char* d = new char[10];
  char* e = new char[10];

  // a[0]='e';
  // a=e;

  // b[0] = 'e';
  b = e;

  c[0] = 'e';
  // c = e;

  d[0] = 'e';
  d = e;

  delete[] a, b, c, d, e;

  return 0;
}
```

&emsp;&emsp; 下面解释为啥会出现这种情况，我们注意到const关键字，指的是不可修改的意思，对于b而言，const 修饰char*,表面char*不可修改即指针指向的内容不可修改，对于c而言const修饰c，表示c这个指针本身不可修改。


