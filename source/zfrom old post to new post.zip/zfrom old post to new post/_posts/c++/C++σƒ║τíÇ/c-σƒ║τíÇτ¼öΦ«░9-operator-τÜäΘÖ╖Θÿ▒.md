---
title: c++基础笔记9 - operator=()的陷阱
mathjax: true
categories:
  - c++笔记
  - c++基础笔记
tags:
  - c++笔记
  - c++基础笔记
keywords:
  - c++笔记
  - c++基础笔记
abbrlink: f7b1688f
date: 2020-03-13 19:35:01
---

# operator=
&emsp;&emsp; 定义赋值函数难吗？难，真的特别难，如果你能看出下面的代码中赋值函数的问题，那你就懂为什么难了。
```cpp
#include <iostream>
using namespace std;

class my_class {
  int *p;

 public:
  my_class &operator=(const my_class &rhs) {
    delete p;
    p = new int(*rhs.p);
    return*this;
  }
};

int main() {}
```
<!---more-->
&emsp;&emsp; 这里的问题其实很明显，这个赋值不支持自我赋值。解决方案可以说在最前面特判掉自我赋值，或者是先拷贝最后再delete，又或者是用拷贝构造函数拷贝一份，然后swap来实现。
