---
title: linux指令学习20-chmod
mathjax: true
categories:
  - linux指令学习
tags:
  - linux指令学习
keywords:
  - linux指令学习
abbrlink: 27136
date: 2020-04-07 15:25:07
---

# 用户分组
&emsp;&emsp; linux中每个文件和目录都有访问权限，分别是只读、只写、可执行

# 权限分类
&emsp;&emsp; 用户权限即自己的权限，用户组权限即同组人的权限，其他权限即和自己不同组的人的权限，所有人的权限即所有人的权限

<!--more-->

# 权限

符号|操作|数字
-|-|-
r|读|4
w|写|2
x|执行|1
d|目录
+|增加权限
-|取消权限
=|赋予权限并取消其他权限


# chmodu
&emsp;&emsp; 修改文件的权限


# 参考
[文件权限中 chmod、u+x、u、r、w、x分别代表什么](https://blog.csdn.net/BjarneCpp/article/details/79912495)
