---
title: linux指令学习1-init
mathjax: true
categories:
  - linux指令学习
tags:
  - linux指令学习
keywords:
  - linux指令学习
abbrlink: f1be20f9
date: 2020-03-27 12:11:28
---

# linux运行级别
&emsp;&emsp; linux一共有7个级别，分别为
0关机、
1单用户、
2无网多用户、
3有网多用户，
4保留，
5图形界面，
6重启。
在文件/etc/inittab中指定了级别。
<!---more-->
# 查看运行级别
&emsp;&emsp; 查看文件/etc/inittab 

# 修改运行级别
```
init 3
```

# 如何找回root密码
&emsp;&emsp; 进入单用户模式，然后修改密码，因为进入单用户模式不需要密码就可以登陆。
&emsp;&emsp; 进入grub中，按e编辑指令，修改kernel，输入1进入单用户级别，输入b启动,用passwd root修改密码


