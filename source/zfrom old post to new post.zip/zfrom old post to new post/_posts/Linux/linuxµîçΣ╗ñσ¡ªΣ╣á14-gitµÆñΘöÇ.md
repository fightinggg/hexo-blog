---
title: linux指令学习14-git撤销
mathjax: true
categories:
  - linux指令学习
  - git指令
tags:
  - linux指令学习
  - git指令
keywords:
  - linux指令学习
  - git指令
abbrlink: 1208285b
date: 2020-03-29 17:34:35
---

# 撤销
&emsp;&emsp; 假设你犯了一个严重的错误
```
rm *.txt
```
&emsp;&emsp; 代码没了我们来看看git的状态
```
git status
```
&emsp;&emsp; 看到了如下的输出
```
On branch master
Changes not staged for commit:
  (use "git add/rm <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	deleted:    a.txt
	deleted:    a2.txt
	deleted:    a3.txt
	deleted:    a4.txt
	deleted:    a5.txt
	deleted:    b.txt

no changes added to commit (use "git add" and/or "git commit -a")
```

<!---more-->
&emsp;&emsp; check
```
git checkout
```
&emsp;&emsp;  看到了这些输出,他说我们删了很多东西，其实和git status的一样
```
D	a.txt
D	a2.txt
D	a3.txt
D	a4.txt
D	a5.txt
D	b.txt
```
&emsp;&emsp; 从暂存区恢复指定文件
```
git checkout -- a.txt
cat a.txt
```
&emsp;&emsp; 我们发现a.txt已经恢复了,输出如下
```
a.txt
```
&emsp;&emsp; 恢复所有文件
```
git checkout -- .
ls 
```
&emsp;&emsp; 看到了输出,终于我们的文件全部恢复，
```
a.txt	a2.txt	a3.txt	a4.txt	a5.txt	b.txt
```
&emsp;&emsp; 恢复更老的版本？使用reset将暂存区的文件修改为版本913bc886088dabee0af5b06351450cad60102c23的a.txt
```
git reset 913bc886088dabee0af5b06351450cad60102c23 a.txt
git status
```
&emsp;&emsp; 我们注意下面的输出,有两条提示，第一条说改变没有被提交，是因为暂存区和版本区的文件不一致，第二条说修改没有储存到暂存区，这是因为工作区和暂存区的文件不一致造成的。
```
On branch master
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	modified:   a.txt

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   a.txt
```
&emsp;&emsp; 这时候我们就可以使用checkout将暂存区的文件拿出来放到工作区，
```
git checkout -- a.txt
cat a.txt
git status
```
&emsp;&emsp; 我们发现a.txt已经恢复到初始的版本的了。我们查看状态发现工作区和暂存区的差异已经消失了，这就已经达到了恢复文件的目的。
```
On branch master
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	modified:   a.txt

```

