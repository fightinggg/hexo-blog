---
title: linux指令学习13-git提交
mathjax: true
categories:
  - linux指令学习
  - git指令
tags:
  - linux指令学习
  - git指令
keywords:
  - linux指令学习
  - git指令
abbrlink: e3d67fb3
date: 2020-03-29 16:38:08
---

# 提交
&emsp;&emsp; 然后我们就可以尝试去提交我们的
```
git commit -m 'first commit'
```
&emsp;&emsp; 我们得到了如下输出
```
[master (root-commit) 913bc88] first commit
 1 file changed, 1 insertion(+)
 create mode 100644 a.txt
```
&emsp;&emsp; 查看git日志
```
git log
```

<!---more-->
&emsp;&emsp; 得到了输出
```
commit 913bc886088dabee0af5b06351450cad60102c23 (HEAD -> master)
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:45:19 2020 +0800

    first commit
```
&emsp;&emsp; 我们尝试将b.txt也提交上去
```
git add b.txt
git commit -m 'second commit'
```
&emsp;&emsp; 再次查看log
```
commit fbdd818849343a78d0e6ccd8d5ce0f35d9d8b123 (HEAD -> master)
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:48:56 2020 +0800

    second commit

commit 913bc886088dabee0af5b06351450cad60102c23
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:45:19 2020 +0800

    first commit
```
# 更多的文件
&emsp;&emsp; 加入更多的文件
```
touch a2.txt a3.txt a4.txt a5.txt
```
&emsp;&emsp; 将他们全部提交
```
git add .
git commit -m 'third commit'
git log
```
&emsp;&emsp; 我们现在看到有了3次提交
```
commit 9d1f0b1c3ecd11e5c629c0dd0bfdf4118ad4e999 (HEAD -> master)
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:52:36 2020 +0800

    third commit

commit fbdd818849343a78d0e6ccd8d5ce0f35d9d8b123
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:48:56 2020 +0800

    second commit

commit 913bc886088dabee0af5b06351450cad60102c23
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:45:19 2020 +0800

    first commit
```

# 修改后的文件
&emsp;&emsp; 如果我们修改了一个文件
```
echo "hellp" >> a.txt
git status
```
&emsp;&emsp; 我们看到了git提示有文件被修改了
```
On branch master
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   a.txt

no changes added to commit (use "git add" and/or "git commit -a")
```
&emsp;&emsp; 将它提交
```
git commit -am 'modified a.txt'
```
&emsp;&emsp; 看到了输出
```
commit 2e625b6f5de426675e4d2edf8ce86a75acc360de (HEAD -> master)
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:57:43 2020 +0800

    modified a.txt

commit 9d1f0b1c3ecd11e5c629c0dd0bfdf4118ad4e999
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:52:36 2020 +0800

    third commit

commit fbdd818849343a78d0e6ccd8d5ce0f35d9d8b123
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:48:56 2020 +0800

    second commit

commit 913bc886088dabee0af5b06351450cad60102c23
Author: fightinggg <246553278@qq.com>
Date:   Sun Mar 29 16:45:19 2020 +0800

    first commit
```

# 追加提交
&emsp;&emsp; 如果我们发现上一次的提交是没有用的，或者说不想让它出现，又或者说想把它删了，我们使用如下指令
```
echo "b" >> b.txt
git commit --amend
```
&emsp;&emsp; 我们发现我们进入到了vim中
```
modified a.txt

# Please enter the commit message for your changes. Lines starting
# with '#' will be ignored, and an empty message aborts the commit.
#
# Date:      Sun Mar 29 16:57:43 2020 +0800
#
# On branch master
# Changes to be committed:
#	modified:   a.txt
#
# Changes not staged for commit:
#	modified:   b.txt
#
```
&emsp;&emsp; 我们将它修改为
```
modified a.txt b.txt

# Please enter the commit message for your changes. Lines starting
# with '#' will be ignored, and an empty message aborts the commit.
#
# Date:      Sun Mar 29 16:57:43 2020 +0800
#
# On branch master
# Changes to be committed:
#	modified:   a.txt
#
# Changes not staged for commit:
#	modified:   b.txt
#
```
&emsp;&emsp; 最后再次查看log
```
git log --oneline
```
&emsp;&emsp; 我们得到了下面的输出，上一次的提交被现在的提交覆盖了
```
105a02a (HEAD -> master) modified a.txt b.txt
9d1f0b1 third commit
fbdd818 second commit
913bc88 first commit
```

