---
title: 234Tree
mathjax: true
categories:
  - myself_library
  - datastructure
  - tree
tags:
  - myself_library
  - datastructure
  - tree
keywords:
  - myself_library
  - datastructure
  - tree
abbrlink: 42972ebe
date: 2020-03-16 12:31:10
---

# 234tree
&emsp;&emsp;参见4阶Btree

