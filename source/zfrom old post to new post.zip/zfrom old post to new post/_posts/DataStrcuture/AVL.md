---
title: AVL
mathjax: true
categories:
  - myself_library
  - datastructure
  - tree
tags:
  - myself_library
  - datastructure
  - tree
keywords:
  - myself_library
  - datastructure
  - tree
abbrlink: 1d92c98c
date: 2020-03-16 12:30:38
---


# AVL Tree
&emsp;&emsp; AVL Tree使用高度差作为平衡因子，他要求兄弟的高度差的绝对值不超过1
## code
<details>
<summary>avl Tree代码</summary>
{% include_code tree lang:cpp cpp/perfect/data_structure/avl_tree.h %}
</details>


