---
title: B+Tree
mathjax: true
categories:
  - myself_library
  - datastructure
  - tree
tags:
  - myself_library
  - datastructure
  - tree
keywords:
  - myself_library
  - datastructure
  - tree
abbrlink: 730b3a2f
date: 2020-03-16 12:30:50
---

## B+树优点
&emsp;&emsp; 因为内部节点、根节点保存的是索引(指针),这导致单位储存空间储存的指针要比单位空间储存的键多得多，这同时导致了B+树能够比B树更加扁平。

## 代码
&emsp;&emsp; 这东西实现难度有点高，太码农了，我随缘实现吧。哈哈哈哈哈哈。


