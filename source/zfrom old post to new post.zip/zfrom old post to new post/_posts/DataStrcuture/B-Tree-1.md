---
title: B*Tree
mathjax: true
categories:
  - myself_library
  - datastructure
  - tree
tags:
  - myself_library
  - datastructure
  - tree
keywords:
  - myself_library
  - datastructure
  - tree
abbrlink: 4e6b139f
date: 2020-03-16 12:31:00
---
# B* Tree
&emsp;&emsp; B*树在B+树的基础上再把内部节点也整上链表，同时要求空间使用率为$\frac{2}{3}$而不是$\frac{1}{2}$

## 代码
&emsp;&emsp; 随缘


