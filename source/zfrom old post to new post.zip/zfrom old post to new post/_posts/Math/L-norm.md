---
title: L norm
mathjax: true
categories:
  - 图形学
  - mash Denoising
  - L范数
abbrlink: bee14e0c
date: 2019-12-13 10:12:41
tags:
keywords:
---

### L范数
常见的L范数有三种$L_0 norm,L_1 norm,L_2 norm$

### $L_0范数$
$L_0范数$指的是向量中非0项的个数

### $L_1范数$
$L_1范数$是曼哈顿距离

### #L_2范数#
$L_2范数$是欧几里得距离
