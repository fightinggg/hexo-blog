---
title: 操作系统9-CPU调度
mathjax: true
categories:
  - 操作系统
tags:
  - 操作系统
keywords:
  - 操作系统
abbrlink: 6c2edf04
date: 2020-04-01 21:37:45
---
# CPU调度
# 调度指标
&emsp;&emsp; CPU使用率(CPU忙状态所占的时间比例)，吞吐量(单位时间内完成的进程数量)，周转时间(一个进程从初始化到结束，花费的所有时间), 等待时间(进程在就绪队列中等待的总时间)， 响应时间(一个请求从提交到产生相应所花费的时间)
# FCFS 
&emsp;&emsp; first come first served
&emsp;&emsp; 先来先服务
# SPN
&emsp;&emsp; Shortest Process Next
&emsp;&emsp; 短进程优先 （抢占或者不抢占）
&emsp;&emsp; 导致长任务饥饿
# HRRN
&emsp;&emsp; Highest Response Ratio Next
&emsp;&emsp; 最高响应比优先，等待时间/执行时间
&emsp;&emsp; 不可抢占，关注等待，防止无期限推迟。
<!-- more -->
# Round Robin
&emsp;&emsp; 时间片轮循
&emsp;&emsp; 时间片太长导致退化为FCFS，太短导致吞吐量受影响
# Multilevel Feedback Queue
&emsp;&emsp; 优先级队列中的轮循，把所有就绪进程分为不同的级别队列，分为交互性和后台，每个队列有自己的调度方法，一个进程可以在不同队列中移动，时间片大小随优先级增加而减少，如果一个认为在当前时间片没有完成，则降级,获得更多的时间片
# Fair Share Scheduling
&emsp;&emsp; 公平共享调度
# 实时调度
&emsp;&emsp; 强实时系统，保证在时间内完成，
&emsp;&emsp; 弱实时系统，尽量在时间内完成，
# 静态优先级调度
&emsp;&emsp; 在任务前就确定了优先级,如RM(Rate Monotonic)速率单调调度，周期越短优先级越高
# 动态优先级调度
&emsp;&emsp; 在运行期间确定优先级，EDF(Earliest Deadline First)最早期限调度，Dealine越早就越先调度。
# 多处理器调度
&emsp;&emsp; 主要考虑负载均衡，
# 优先级反转
&emsp;&emsp; 先给3个任务，T1&gt;T2&gt;T3, 如果T3先出现，则调度T3，T3访问了一个共享资源，后来T1来了，T1优先级最高，所以抢占，但是共享资源被T3锁住了，于是阻塞，T1开始执行，但是这时候T2横插一手，导致T1有不能执行，最终导致T1不能正常完成，
&emsp;&emsp; 我们应该设计优先级继承，即当T1在等待T3执行完成的时候，将T3的优先级提升到和T1一样，让T2插不进来，才能保证T3的完成，进而释放资源好让T1完成。
&emsp;&emsp; 这个方法又叫优先级天花板


