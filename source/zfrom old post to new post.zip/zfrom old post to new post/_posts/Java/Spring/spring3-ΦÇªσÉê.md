---
title: spring3-耦合
mathjax: true
abbrlink: 52570c80
date: 2020-04-02 22:36:23
categories:
  - Java
  - spring
tags:
  - Java
  - spring
keywords:
  - Java
  - spring
---

# 耦合
&emsp;&emsp; 我们考虑一个web应用，使用三层架构: 视图层+业务层+持久层，
&emsp;&emsp; 视图层依赖业务层，业务层依赖持久层，这是非常不好的现象，当我们的持久层需要改变的时候，整个项目都要改变，项目非常不稳定。

# 怎么解决
&emsp;&emsp; 工厂！
<!-- more -->

# Bean
&emsp;&emsp; Bean就是可重用组件

# JavaBean
&emsp;&emsp; JavaBean不是实体类，JavaBean远大于实体类，JavaBean是Java语言编写的可重用组件

#  解决
&emsp;&emsp; 使用配置文件来配置service和dao，通过读取配置文件，反射创建对象，这样程序就不会在编译器发生错误了。
&emsp;&emsp; 考虑用一个BeanFactory来实现读取配置文件和反射
&emsp;&emsp; 但是注意到我们实现的时候，如果每次都去创建一个新的对象，我们的BeanFactory可能会非常大，所以我们需要在工厂中用一个字典来保存对象，这就成了一个容器。 

# IOC
&emsp;&emsp; 控制反转，我们不需要自己new了，让工厂给我们提供服务，这就是IOC，把对象的控制权交给工厂。
