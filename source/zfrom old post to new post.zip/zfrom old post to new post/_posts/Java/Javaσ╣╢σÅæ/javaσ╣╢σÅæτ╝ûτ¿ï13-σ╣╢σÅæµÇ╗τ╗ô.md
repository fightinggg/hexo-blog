---
title: Java并发编程13-并发总结
mathjax: true
abbrlink: 27900
date: 2020-04-13 12:38:15
categories:
- Java
- Java并发
tags:
- Java
- Java并发
keywords:
- Java
- Java并发
---

# Java并发
- Tread 创建线程
- Runnable 创建线程
- Callable+Future创建线程
- synchronized 加锁
- wait/notify 释放锁并进入阻塞队列
- park/unpark 类似上
- ReentrantLock 重入锁
- await/signal 信号量
- volatile
- happens-before
- CAS
- ThreadPollExecutor
- Fork/join
- AQS
- ReentrantReadWriteLock
- StampedLock
- CountdownLatch
- cyclicbarrier
- CopyOnWrite
- ConcurrentHashMap
