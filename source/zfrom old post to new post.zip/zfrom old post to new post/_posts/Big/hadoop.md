---
title: hadoop
mathjax: true
categories:
  - 大数据
  - hadoop
tags:
  - 大数据
  - hadoop
keywords:
  - 大数据
  - hadoop
abbrlink: b4989874
date: 2020-03-24 14:37:30
---

# hadoop 
&emsp;&emsp; hadoop = common+hdfs+mapreduce+yarn

# common
&emsp;&emsp; 工具、rpc通信

# hdfs
&emsp;&emsp; 分布式文件系统，一个文件分成多个128Mb的文件，存储在多个节点，为了保证分区容错性，存有备份，默认为3。主从架构。
<!---more-->
## namenode
&emsp;&emsp; 用来记录各个文件的block的编号、各个block的位置、抽象目录树
&emsp;&emsp; 处理读写请求
&emsp;&emsp; 可以有多个namenode
## secondarynamenode
&emsp;&emsp; 用来备份namenode,当namenode宕机的时候，帮助namenode恢复
## datanode
&emsp;&emsp; 用来储存数据
## 副本机制
&emsp;&emsp; 如果一个datanode挂了，就再开一个datanode，然后吧挂了的数据通过备份推出来存进去，如果之前那个挂了的又活了，则选择一个节点删掉。副本过多将导致维护成本提高
## 优点
- 可构建在廉价机器上
- 高容错性 : 自动恢复
## 缺点
- 不支持数据修改(尽管支持改名和删除)
- 延迟高
- 不擅长存储小文件，寻址时间长，空间利用低


# yarn
&emsp;&emsp; 资源调度、管理框架
- resourcemanager 统筹资源
- nodemanager 资源调度

# mapreduce
&emsp;&emsp; 分布式计算框架

