import os




# 警告！这个会写文件 "/Users/s/Desktop/hexo/source/_post"
#  f = open("/Users/s/Desktop/hexo/source/_post"+"/"+name,"w")
for root,dirs,files in os.walk(r"./_posts"):
    for file in files:
        if(file[0]=='.'):
            continue
        #  print(os.path.join(root,file))
        with open(os.path.join(root,file),"r") as f:
            s = f.read().split("---\n")
            heads = s[1].split("\n")
            title = ""
            date = ""
            for head in heads:
                x = head.split(":")
                if(x[0]=="title"):
                    title = x[1].strip()
                    while(title[0]==' ' or title[0]=='\''):
                        title = title[1:]
                    while(title[-1]==' ' or title[-1]=='\'' or title[-1]=='·'):
                        title = title[:-1]

                if(x[0]=="date"):
                    date = x[1][1:]+"-"+x[2]+"-"+x[3]
                    date = date.replace(" ","-");
                    date = "["+date+"]"

            #  print(len(sl),end="")
            f.close()
            name = date+title+".md"
            name = name.replace("/","-")
            #  print(name)
            dst = "./gerneral"+"/"+root[2:]+"/"+name
            print(dst)
            f = open(dst,'w')
            s = "---\nmathjax: true\n---\n"+s[2]
            f.write(s)
            f.close()



