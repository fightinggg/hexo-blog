
document.writeln('                    </div>																																																	');
document.writeln('                    </div>																																																	');
document.writeln('                    <div id="down"><center>博主蒟蒻 可以随意转载 但要附上本文链接</center><center>广告位招租</center><center><div style="width:80%"><hr></div></center><br></div>																																																');
document.writeln('                    </div>																																																	');
document.writeln('                    </body>																																																	');

