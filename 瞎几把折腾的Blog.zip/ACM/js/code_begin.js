   document.writeln("   <section class=\"block\"> <input type=\"checkbox\"><div class=\"case-block\"> <div>代码展开</div> <div>代码收起</div></div><div class=\"code_in\">  ");
