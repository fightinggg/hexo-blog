document.writeln('                   <body>     																																					');
document.writeln('                   <div id="myweb"> 																																												');

document.writeln('   <div id="up"> <center><a href="http://fightinggg.coding.me/">逐    梦</a></center></div>																	');
document.writeln('                   <nav id="menu" class="menu">     																																					');
document.writeln('                   <div id="right">																																													');

document.writeln('                   <div id="right_in">																																												');
document.writeln('                        <h3><center> <a href="https://github.com/fightinggg/ACM">github</a></br>	</center></h3>																																		');
document.writeln('                        <hr>																																																');
document.writeln('                                                    <a href="https://github.com/fightinggg/ACM">github</a></br>													');
document.writeln('                        </div>																																																');

document.writeln('                   <div id="right_in">																																												');
document.writeln('                        <h3><center>ACM模版</center></h3>																																		');
document.writeln('                        <hr>																																																');
document.writeln('                                                    <a href="http://fightinggg.github.io/ACM/stencil/math/">数论</a></br>															');
document.writeln('                                                    <a href="http://fightinggg.github.io/ACM/stencil/data_struct/">数据结构</a></br>										');
document.writeln('                                                   <a href="http://fightinggg.github.io/ACM/stencil/string">字符串</a></br>														');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/stencil/dp">dp</a></br>																	');
document.writeln('                                               		 <a href="http://fightinggg.github.io/ACM/stencil/graph_theory/">图论</a></br>											');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/stencil/computational_geometry">计算几何</a></br>					');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/stencil/thinging">思维与算法</a></br>											');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/stencil/Yuki_technique/">黑科技</a></br>										');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/stencil/acm_head_file.html">快读</a></br>									');
document.writeln('                        </div>																																																');

document.writeln('                   <div id="right_in">																																												');
document.writeln('                        <h3><center>ACM题型</center></h3>																																		');
document.writeln('                        <hr>																																																');
document.writeln('                                                    <a href="http://fightinggg.github.io/ACM/problem/math/">数论</a></br>														');
document.writeln('                                                    <a href="http://fightinggg.github.io/ACM/problem/data_struct/">数据结构</a></br>										');
document.writeln('                                                   <a href="http://fightinggg.github.io/ACM/problem/string">字符串</a></br>													');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/problem/dp">dp</a></br>																');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/problem/graph_theory/">图论</a></br>											');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/problem/computational_geometry">计算几何</a></br>					');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/problem/thinging">思维与算法</a></br>										');
document.writeln('                                                	<a href="http://fightinggg.github.io/ACM/problem/Yuki_technique/">黑科技</a></br>									');
document.writeln('                        </div>																																																');

document.writeln('                   <div id="right_in">																																												');
document.writeln('                        <h3><center>生成博客</center></h3>																																				');
document.writeln('                        <hr>																																																');
document.writeln('                                                    <a href="http://fightinggg.github.io/ACM/reading_problem/indexs/reading_index.html" target="_blank">阅题</a></br>											');
document.writeln('                                                    <a href="http://fightinggg.github.io/ACM/blog/span/index.html" target="_blank">生成博客二代</a></br>											');
document.writeln('                        </div>																																																');

document.writeln('                   <div id="right_in">																																												');
document.writeln('                        <h3><center>珍藏网站</center></h3>																																		');
document.writeln('                        <hr>																																																');
document.writeln('                                                    <a href="https://gcc.gnu.org/onlinedocs/gcc/Other-Builtins.html" target="_blank">gcc内建函数</a></br>	');
document.writeln('                                                    <a href="https://www.codecogs.com/latex/eqneditor.php" target="_blank">数学公式</a></br>					');
document.writeln('                                                    <a href="http://hzwer.com" target="_blank">hzwer</a></br>																			');
document.writeln('                                                    <a href="http://www.jj20.com"  target="_blank">桌面高清背景图片</a></br>													');
document.writeln('                        </div>																																																');

document.writeln('                   <div id="right_in">																																												');
document.writeln('                        <h3><center>友链</center></h3>																																				');
document.writeln('                        <hr>																																																');
document.writeln('                                                    <a href="https://blog.csdn.net/weixin_41863129" target="_blank">yg</a></br>											');
document.writeln('                                                    <a href="https://decaku.github.io"  target="_blank">zwg</a></br>																	');
document.writeln('                                                    <a href="https://www.cnblogs.com/chunibyo/"  target="_blank">wly</a></br>																	');
document.writeln('                        </div>																																																');

document.writeln('                    </div>																																																	');
document.writeln('                    <div id="left">																																																	');
document.writeln('                    <div id="left_in">																																																	');

