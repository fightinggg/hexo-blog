'use strict';

if (!hexo.config.lazyload || !hexo.config.lazyload.enable) {
    return;
}
if (hexo.config.lazyload.onlypost) {
    console.log("1");
    hexo.extend.filter.register('after_post_render', require('hexo-fightinggg-lazyload-image/lib/process').processPost);
}
else {
    hexo.extend.filter.register('after_render:html', require('hexo-fightinggg-lazyload-image/lib/process').processSite);
}
hexo.extend.filter.register('after_render:html', require('hexo-fightinggg-lazyload-image/lib/addscripts').addScript);
