
hexo.extend.filter.register('before_post_render', function (data) {
});
