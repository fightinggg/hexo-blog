// Copyright © 2016 TangDongxin

// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
// TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
// OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"use strict";

var fs = require("hexo-fs");
var pathFn = require("path");



hexo.extend.filter.register("after_generate", function (post) {
    // config
    var mathjaxConfig = {}
    mathjaxConfig.uri = hexo.theme.config.vendors.mathjax || '//cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js'

    fs.writeFile(pathFn.join(hexo.public_dir, 'api', 'mathjaxConfig', 'index.html'), JSON.stringify(mathjaxConfig))

    // js
    var context =`
    
if (typeof MathJax === 'undefined') {
    $.get('${hexo.config.root}api/mathjaxConfig/').then(config => {
        config = JSON.parse(config)
        window.MathJax = {
            loader: {
                load: ['[tex]/mhchem'],
                source: {
                    '[tex]/amsCd': '[tex]/amscd',
                    '[tex]/AMScd': '[tex]/amscd'
                }
            },
            tex: {
                inlineMath: { '[+]': [['$', '$']] },
                packages: { '[+]': ['mhchem'] },
                tags: 'ams'
            },
            options: {
                renderActions: {
                    findScript: [10, doc => {
                        document.querySelectorAll('script[type^="math/tex"]').forEach(node => {
                            const display = !!node.type.match(/; *mode=display/);
                            const math = new doc.options.MathItem(node.textContent, doc.inputJax[0], display);
                            const text = document.createTextNode('');
                            node.parentNode.replaceChild(text, node);
                            math.start = { node: text, delim: '', n: 0 };
                            math.end = { node: text, delim: '', n: 0 };
                            doc.math.push(math);
                        });
                    }, '', false],
                    insertedScript: [200, () => {
                        document.querySelectorAll('mjx-container').forEach(node => {
                            let target = node.parentNode;
                            if (target.nodeName.toLowerCase() === 'li') {
                                target.parentNode.classList.add('has-jax');
                            }
                        });
                    }, '', false]
                }
            }
        };
        (function () {
            var script = document.createElement('script');
            script.src = config.uri;
            script.defer = true;
            document.head.appendChild(script);
        })();
    })
} else {
    MathJax.startup.document.state(0);
    MathJax.texReset();
    MathJax.typeset();
}

    `

    fs.writeFile(pathFn.join(hexo.public_dir, 'js', 'mathjax.js'),context)


});

