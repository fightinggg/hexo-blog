//
// Created by s on 2019/11/7.
//


/*
 *
 * __builtin_popcount(n) 该函数时判断n的二进制中有多少个1
 * __builtin_parity(n) 该函数是判断n的二进制中1的个数的奇偶性 偶数个，输出0 奇数个，输出1
 * __builtin_ffs(n) 该函数判断n的二进制末尾最后一个1的位置，从一开始
 * __builtin_ctz(n) 该函数判断n的二进制末尾后面0的个数，当n为0时，和n的类型有关
 *
 * */