---
date: 2020-12-29 00:00:00
updated: 2020-12-29 00:00:00
mathjax: true
typora-root-url: ..\..
---



# 配置安全域名即可

![](/images/image-2021-03-13-22.58.05.691.png)