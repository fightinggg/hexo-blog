---
date: 2020-06-20 18:30:51
updated: 2020-06-20 18:30:51
mathjax: true
---


# 《Data Mining Concepts and Techniques · JiaWei Han Micheline Kamber Jian Pai》学习总结

<!-- more -->

[点我直接查看pdf文件](pdf/data_mining.pdf)

<iframe name="container_ifranme" id="iframeId" frameborder="no" border="0" src="pdf/data_mining.pdf" width="100%" height="7000px" style="background-color:white" ></iframe>