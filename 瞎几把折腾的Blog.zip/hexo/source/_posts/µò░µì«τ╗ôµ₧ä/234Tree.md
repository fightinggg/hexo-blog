---
date: 2020-03-16 12:31:10
updated: 2020-03-16 12:31:10
mathjax: true
---

# 234tree
参见4阶Btree