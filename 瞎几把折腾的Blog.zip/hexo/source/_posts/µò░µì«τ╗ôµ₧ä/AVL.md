---
date: 2020-03-16 12:30:38
updated: 2020-03-16 12:30:38
mathjax: true
---


# AVL Tree
 AVL Tree使用高度差作为平衡因子，他要求兄弟的高度差的绝对值不超过1
## code
<details>
<summary>avl Tree代码</summary>
{% include_code tree lang:cpp cpp/perfect/data_structure/avl_tree.h %}
</details>