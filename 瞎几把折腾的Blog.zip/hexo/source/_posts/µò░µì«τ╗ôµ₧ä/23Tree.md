---
date: 2020-03-16 12:31:05
updated: 2020-03-16 12:31:05
mathjax: true
---

# 23tree
参见3阶Btree