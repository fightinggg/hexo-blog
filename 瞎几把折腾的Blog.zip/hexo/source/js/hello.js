document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        msgUtils.showSuccessMsg('欢迎来到Believe it站点', 1000)
    }, 3000);
})